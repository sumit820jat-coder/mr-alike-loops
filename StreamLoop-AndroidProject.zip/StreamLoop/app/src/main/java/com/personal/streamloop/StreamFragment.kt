package com.personal.streamloop

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment

class StreamFragment : Fragment(R.layout.fragment_stream) {

    private val platforms = listOf("YouTube", "Custom RTMP", "Facebook", "Instagram", "TikTok")
    private var videoNames: List<String> = emptyList()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val spinnerPlatform = view.findViewById<Spinner>(R.id.spinnerPlatform)
        val spinnerVideo = view.findViewById<Spinner>(R.id.spinnerVideo)
        val tvKeyLabel = view.findViewById<TextView>(R.id.tvKeyLabel)
        val etStreamKey = view.findViewById<EditText>(R.id.etStreamKey)
        val tvNoVideos = view.findViewById<TextView>(R.id.tvNoVideos)
        val btnStart = view.findViewById<Button>(R.id.btnStart)
        val btnStop = view.findViewById<Button>(R.id.btnStop)
        val tvStatus = view.findViewById<TextView>(R.id.tvStatus)
        val tvLog = view.findViewById<TextView>(R.id.tvLog)

        spinnerPlatform.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, platforms)
        spinnerPlatform.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                when (platforms[position]) {
                    "YouTube" -> {
                        tvKeyLabel.text = "Stream Key"
                        etStreamKey.hint = "Paste your YouTube stream key"
                    }
                    "Custom RTMP" -> {
                        tvKeyLabel.text = "Full RTMP URL"
                        etStreamKey.hint = "rtmp://your-server/live/key"
                    }
                    else -> {
                        Toast.makeText(requireContext(), "${platforms[position]} abhi supported nahi hai. YouTube ya Custom RTMP use karo.", Toast.LENGTH_LONG).show()
                        spinnerPlatform.setSelection(0)
                    }
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        StreamRepository.videos.observe(viewLifecycleOwner) { list ->
            videoNames = list.map { it.displayName }
            val hasVideos = list.isNotEmpty()
            tvNoVideos.visibility = if (hasVideos) View.GONE else View.VISIBLE
            spinnerVideo.visibility = if (hasVideos) View.VISIBLE else View.GONE
            spinnerVideo.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, videoNames)
        }

        StreamRepository.status.observe(viewLifecycleOwner) { status ->
            tvStatus.text = "Status: $status"
            val running = status == "Streaming" || status == "Starting"
            btnStart.isEnabled = !running
            btnStop.isEnabled = running
        }

        StreamRepository.log.observe(viewLifecycleOwner) { tvLog.text = it }

        btnStart.setOnClickListener {
            val key = etStreamKey.text.toString().trim()
            val platform = platforms[spinnerPlatform.selectedItemPosition]
            val videos = StreamRepository.videos.value ?: emptyList()
            val selectedIndex = spinnerVideo.selectedItemPosition

            if (key.isEmpty()) {
                Toast.makeText(requireContext(), "Stream key / RTMP URL daalo", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (videos.isEmpty() || selectedIndex < 0 || selectedIndex >= videos.size) {
                Toast.makeText(requireContext(), "Video select karo", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val video = videos[selectedIndex]
            val rtmpUrl = if (platform == "YouTube") "rtmp://a.rtmp.youtube.com/live2/$key" else key

            val intent = Intent(requireContext(), StreamService::class.java).apply {
                action = StreamService.ACTION_START
                putExtra(StreamService.EXTRA_VIDEO_PATH, video.path)
                putExtra(StreamService.EXTRA_VIDEO_NAME, video.displayName)
                putExtra(StreamService.EXTRA_RTMP_URL, rtmpUrl)
                putExtra(StreamService.EXTRA_PLATFORM, platform)
            }
            ContextCompat.startForegroundService(requireContext(), intent)
        }

        btnStop.setOnClickListener {
            val intent = Intent(requireContext(), StreamService::class.java).apply {
                action = StreamService.ACTION_STOP
            }
            requireContext().startService(intent)
        }
    }
}
