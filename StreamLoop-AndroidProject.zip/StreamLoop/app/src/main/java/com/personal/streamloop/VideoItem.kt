package com.personal.streamloop

data class VideoItem(
    val fileName: String,
    val displayName: String,
    val path: String,
    val sizeBytes: Long,
    val durationSeconds: Int
)
