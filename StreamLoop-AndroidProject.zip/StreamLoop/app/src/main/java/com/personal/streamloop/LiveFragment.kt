package com.personal.streamloop

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment

class LiveFragment : Fragment(R.layout.fragment_live) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val title = view.findViewById<TextView>(R.id.tvLiveTitle)
        val detail = view.findViewById<TextView>(R.id.tvLiveDetail)
        val btnGoToStream = view.findViewById<Button>(R.id.btnGoToStream)
        val btnStopLive = view.findViewById<Button>(R.id.btnStopLive)

        StreamRepository.status.observe(viewLifecycleOwner) { status ->
            val isLive = status == "Streaming" || status == "Starting"
            if (isLive) {
                title.text = "🔴 Live Now"
                detail.text = "${StreamRepository.liveVideoName.value} -> ${StreamRepository.livePlatform.value}"
                btnGoToStream.visibility = View.GONE
                btnStopLive.visibility = View.VISIBLE
            } else {
                title.text = "All Streams Offline"
                detail.text = "You have no active streams. Start one from the \"Stream\" tab."
                btnGoToStream.visibility = View.VISIBLE
                btnStopLive.visibility = View.GONE
            }
        }

        btnGoToStream.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(R.id.nav_stream)
        }

        btnStopLive.setOnClickListener {
            val intent = Intent(requireContext(), StreamService::class.java).apply {
                action = StreamService.ACTION_STOP
            }
            requireContext().startService(intent)
        }
    }
}
