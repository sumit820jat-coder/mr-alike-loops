package com.personal.streamloop

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment

class SettingsFragment : Fragment(R.layout.fragment_settings) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<View>(R.id.itemHelp).setOnClickListener {
            showDialog(
                "How to use the app",
                "1. Videos tab mein jaake apna video upload karo.\n" +
                "2. Stream tab mein YouTube select karo aur apni Stream Key paste karo.\n" +
                "3. Upload kiya hua video select karo.\n" +
                "4. Start Streaming dabao. App background mein 24/7 loop karta rahega.\n" +
                "5. Rokne ke liye Stop dabao."
            )
        }

        view.findViewById<View>(R.id.itemPrivacy).setOnClickListener {
            showDialog(
                "Privacy Policy",
                "Ye ek personal-use app hai. Aapke videos, stream key aur logs sirf isi device par store hote hain. Kuch bhi kisi server par upload nahi hota, sirf aapke selected platform (jaise YouTube) ko RTMP se stream jaata hai."
            )
        }

        view.findViewById<View>(R.id.itemTerms).setOnClickListener {
            showDialog(
                "Terms & Conditions",
                "Ye app sirf aapke apne accounts/channels ke personal use ke liye hai. Apni stream key kabhi kisi ke saath share mat karo."
            )
        }

        view.findViewById<View>(R.id.itemAbout).setOnClickListener {
            showDialog("About", "MR ALIKE LOOPS v1.0\nPersonal build.")
        }
    }

    private fun showDialog(title: String, message: String) {
        AlertDialog.Builder(requireContext())
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }
}
