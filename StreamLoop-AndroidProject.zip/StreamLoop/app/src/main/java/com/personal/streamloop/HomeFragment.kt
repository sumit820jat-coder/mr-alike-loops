package com.personal.streamloop

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class HomeFragment : Fragment(R.layout.fragment_home) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val badge = view.findViewById<TextView>(R.id.tvStatusBadge)
        val detail = view.findViewById<TextView>(R.id.tvStatusDetail)
        val batteryWarning = view.findViewById<View>(R.id.batteryWarning)
        val btnFixBattery = view.findViewById<View>(R.id.btnFixBattery)

        checkBatteryOptimization(batteryWarning)

        btnFixBattery.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:${requireContext().packageName}")
                )
                startActivity(intent)
            }
        }

        StreamRepository.status.observe(viewLifecycleOwner) { status ->
            val isLive = status == "Streaming" || status == "Starting"
            badge.text = if (isLive) "Live" else "Offline"
            badge.setBackgroundResource(if (isLive) R.drawable.badge_online else R.drawable.badge_offline)
            detail.text = if (isLive) {
                "Streaming: ${StreamRepository.liveVideoName.value} -> ${StreamRepository.livePlatform.value}"
            } else {
                "You have no active streams."
            }
        }

        view.findViewById<View>(R.id.actionStartStream).setOnClickListener {
            (activity as? MainActivity)?.navigateTo(R.id.nav_stream)
        }
        view.findViewById<View>(R.id.actionUploadVideo).setOnClickListener {
            (activity as? MainActivity)?.navigateTo(R.id.nav_videos)
        }
    }

    override fun onResume() {
        super.onResume()
        view?.findViewById<View>(R.id.batteryWarning)?.let { checkBatteryOptimization(it) }
    }

    private fun checkBatteryOptimization(warningView: View) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = requireContext().getSystemService(PowerManager::class.java)
            val ignoring = pm.isIgnoringBatteryOptimizations(requireContext().packageName)
            warningView.visibility = if (ignoring) View.GONE else View.VISIBLE
        } else {
            warningView.visibility = View.GONE
        }
    }
}
