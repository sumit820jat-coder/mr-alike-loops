package com.personal.streamloop

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class VideosFragment : Fragment(R.layout.fragment_videos) {

    private lateinit var adapter: VideoAdapter

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) importVideo(uri)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recycler = view.findViewById<RecyclerView>(R.id.recyclerVideos)
        val storageText = view.findViewById<TextView>(R.id.tvStorageText)
        val storageBar = view.findViewById<ProgressBar>(R.id.storageBar)

        adapter = VideoAdapter(emptyList()) { item ->
            StreamRepository.deleteVideo(item)
            Toast.makeText(requireContext(), "Deleted: ${item.displayName}", Toast.LENGTH_SHORT).show()
        }
        recycler.layoutManager = LinearLayoutManager(requireContext())
        recycler.adapter = adapter

        view.findViewById<View>(R.id.uploadCard).setOnClickListener {
            pickVideoLauncher.launch(arrayOf("video/*"))
        }

        StreamRepository.videos.observe(viewLifecycleOwner) { list ->
            adapter.updateItems(list)
            val usedBytes = StreamRepository.storageUsedBytes()
            val usedGb = usedBytes / (1024.0 * 1024.0 * 1024.0)
            val quotaGb = StreamRepository.STORAGE_QUOTA_BYTES / (1024.0 * 1024.0 * 1024.0)
            val percent = ((usedBytes.toDouble() / StreamRepository.STORAGE_QUOTA_BYTES) * 100).toInt().coerceIn(0, 100)
            storageText.text = String.format("%.1f / %.0f GB", usedGb, quotaGb)
            storageBar.progress = percent
        }
    }

    private fun importVideo(uri: Uri) {
        val name = getFileName(uri) ?: "video_${System.currentTimeMillis()}.mp4"
        Toast.makeText(requireContext(), "Uploading $name...", Toast.LENGTH_SHORT).show()
        val item = StreamRepository.importVideo(requireContext(), uri, name)
        if (item != null) {
            Toast.makeText(requireContext(), "Uploaded: ${item.displayName}", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(requireContext(), "Upload failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getFileName(uri: Uri): String? {
        var name: String? = null
        requireContext().contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx)
        }
        return name
    }
}
