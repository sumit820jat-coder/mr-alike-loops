package com.personal.streamloop

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.lifecycle.MutableLiveData
import java.io.File

/**
 * Simple in-process singleton that all fragments + the streaming service read/write.
 * Keeps things simple for a personal-use app (no database needed).
 */
object StreamRepository {

    const val STORAGE_QUOTA_BYTES = 5L * 1024 * 1024 * 1024 // 5 GB, informational only

    val status = MutableLiveData("Idle")           // Idle | Starting | Streaming
    val liveVideoName = MutableLiveData("")
    val livePlatform = MutableLiveData("")
    val log = MutableLiveData("")

    val videos = MutableLiveData<MutableList<VideoItem>>(mutableListOf())

    private fun videosDir(context: Context): File {
        val dir = File(context.filesDir, "videos")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun loadVideos(context: Context) {
        val dir = videosDir(context)
        val list = dir.listFiles()?.map { f ->
            VideoItem(
                fileName = f.name,
                displayName = f.name,
                path = f.absolutePath,
                sizeBytes = f.length(),
                durationSeconds = getDurationSeconds(f.absolutePath)
            )
        }?.toMutableList() ?: mutableListOf()
        videos.postValue(list)
    }

    /** Copies a picked SAF video into app-private storage so it has a stable path for ffmpeg. */
    fun importVideo(context: Context, source: Uri, originalName: String): VideoItem? {
        val dir = videosDir(context)
        val safeName = "${System.currentTimeMillis()}_${originalName.replace(Regex("[^A-Za-z0-9._-]"), "_")}"
        val destFile = File(dir, safeName)
        context.contentResolver.openInputStream(source)?.use { input ->
            destFile.outputStream().use { output ->
                input.copyTo(output)
            }
        } ?: return null

        val item = VideoItem(
            fileName = safeName,
            displayName = originalName,
            path = destFile.absolutePath,
            sizeBytes = destFile.length(),
            durationSeconds = getDurationSeconds(destFile.absolutePath)
        )
        val current = videos.value ?: mutableListOf()
        current.add(item)
        videos.postValue(current)
        return item
    }

    fun deleteVideo(item: VideoItem) {
        File(item.path).delete()
        val current = videos.value ?: mutableListOf()
        current.removeAll { it.path == item.path }
        videos.postValue(current)
    }

    fun storageUsedBytes(): Long = videos.value?.sumOf { it.sizeBytes } ?: 0L

    fun appendLog(line: String) {
        val prev = log.value ?: ""
        log.postValue(if (prev.isEmpty()) line else "$prev\n$line")
    }

    private fun getDurationSeconds(path: String): Int {
        return try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(path)
            val durMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            retriever.release()
            ((durMs?.toLongOrNull() ?: 0L) / 1000).toInt()
        } catch (e: Exception) {
            0
        }
    }
}
