package com.personal.streamloop

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.Session

class StreamService : Service() {

    companion object {
        const val ACTION_START = "com.personal.streamloop.START"
        const val ACTION_STOP = "com.personal.streamloop.STOP"
        const val EXTRA_VIDEO_PATH = "extra_video_path"
        const val EXTRA_VIDEO_NAME = "extra_video_name"
        const val EXTRA_RTMP_URL = "extra_rtmp_url"
        const val EXTRA_PLATFORM = "extra_platform"

        private const val CHANNEL_ID = "stream_loop_channel"
        private const val NOTIF_ID = 1001
    }

    private var currentSession: FFmpegSession? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val path = intent.getStringExtra(EXTRA_VIDEO_PATH)
                val name = intent.getStringExtra(EXTRA_VIDEO_NAME) ?: "Video"
                val rtmpUrl = intent.getStringExtra(EXTRA_RTMP_URL)
                val platform = intent.getStringExtra(EXTRA_PLATFORM) ?: "YouTube"
                if (path != null && rtmpUrl != null) {
                    startStreaming(path, name, rtmpUrl, platform)
                }
            }
            ACTION_STOP -> stopStreaming()
        }
        return START_NOT_STICKY
    }

    private fun startStreaming(videoPath: String, videoName: String, rtmpUrl: String, platform: String) {
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("Starting..."))
        acquireWakeLock()
        StreamRepository.status.postValue("Starting")
        StreamRepository.liveVideoName.postValue(videoName)
        StreamRepository.livePlatform.postValue(platform)

        // -re              : read input at native frame rate (needed for live pacing)
        // -stream_loop -1  : loop the input video forever
        // -c copy          : remux without re-encoding (fast, low battery/CPU use)
        // -f flv           : output container required by RTMP ingest
        val command = "-re -stream_loop -1 -i \"$videoPath\" -c copy -f flv \"$rtmpUrl\""

        StreamRepository.appendLog("Starting loop stream: $videoName -> $platform")

        currentSession = FFmpegKit.executeAsync(
            command,
            { session: Session ->
                val returnCode = session.returnCode
                when {
                    ReturnCode.isSuccess(returnCode) -> StreamRepository.appendLog("Stream ended normally.")
                    ReturnCode.isCancel(returnCode) -> StreamRepository.appendLog("Stream stopped.")
                    else -> StreamRepository.appendLog("Stream failed. Return code: $returnCode")
                }
                StreamRepository.status.postValue("Idle")
                stopForeground(STOP_FOREGROUND_REMOVE)
                releaseWakeLock()
                stopSelf()
            },
            { log -> StreamRepository.appendLog(log.message) },
            { }
        ) as FFmpegSession

        StreamRepository.status.postValue("Streaming")
        updateNotification("Streaming live: $videoName")
    }

    private fun stopStreaming() {
        currentSession?.let { FFmpegKit.cancel(it.sessionId) }
        StreamRepository.appendLog("Stop requested.")
        StreamRepository.status.postValue("Idle")
        stopForeground(STOP_FOREGROUND_REMOVE)
        releaseWakeLock()
        stopSelf()
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "StreamLoop::StreamingWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire() // held indefinitely until releaseWakeLock() is called on stop
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "MR ALIKE LOOPS", NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("MR ALIKE LOOPS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        super.onDestroy()
        currentSession?.let { FFmpegKit.cancel(it.sessionId) }
        releaseWakeLock()
    }
}
